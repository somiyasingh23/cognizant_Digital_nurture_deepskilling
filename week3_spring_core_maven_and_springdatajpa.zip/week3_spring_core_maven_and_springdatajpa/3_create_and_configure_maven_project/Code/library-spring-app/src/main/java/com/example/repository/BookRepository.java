package com.example.repository;

public class BookRepository {
    public void saveBook() {
        System.out.println("BookRepository: Book saved!");
    }
}
