package com.library.repository;

public class BookRepository {
    public String getBook() {
        return "Effective Java by Joshua Bloch";
    }
}
