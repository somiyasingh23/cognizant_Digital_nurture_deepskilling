package com.example.JUnitSetting;

import org.junit.Test;
import static org.junit.Assert.*;

public class CalculatorTest {

    @Test
    public void testAdd() {
        int result = 2 + 3;
        assertEquals(5, result);
    }
}
